export enum TaskStatus {
    //Define the list of status to be allow.
    OPEN = 'OPEN',
    IN_PROGRESS = 'IN_PROGRESS',
    DONE = 'DONE'
};